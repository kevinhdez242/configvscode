# Explain what you changed.
I changed all the problems the task say I need to correct.

# Did you find it difficult?
No, but there were some things that took me a while to figure out how they work.

# Which challenges you encountered?
The kevin.js file is the most difficult to do I think.

# If there were some steps that you could not complete and why?
I completed all.
