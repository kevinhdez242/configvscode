function sayGoodbye() {
  setTimeout(function() {
      console.log("Goodbye");
  }, 10000);
}

sayGoodbye();
